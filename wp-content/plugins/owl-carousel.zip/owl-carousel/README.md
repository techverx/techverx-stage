wp-plugin-owlcarousel
=====================

A plugin to use Owl Carousel in Wordpress
